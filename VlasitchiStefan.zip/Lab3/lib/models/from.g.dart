// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'from.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

From _$FromFromJson(Map<String, dynamic> json) => From(
      country: json['country'] as String,
      city: json['city'] as String,
    );

Map<String, dynamic> _$FromToJson(From instance) => <String, dynamic>{
      'country': instance.country,
      'city': instance.city,
    };
