class WineBy {
  final String tag;
  final String name;

  WineBy({required this.tag, required this.name});
}
