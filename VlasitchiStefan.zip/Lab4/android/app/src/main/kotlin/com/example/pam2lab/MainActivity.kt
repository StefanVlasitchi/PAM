package com.example.pam2lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
